from fastapi import FastAPI, Form, status
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from models import Student
from database import SessionLocal

app = FastAPI()
templates = Jinja2Templates(directory="templates")

def calculate_grade(marks: int) -> str:
    if marks >= 90:
        return "A+"
    elif marks >= 80:
        return "A"
    elif marks >= 70:
        return "B"
    elif marks >= 60:
        return "C"
    elif marks >= 50:
        return "D"
    else:
        return "F"

@app.get("/")
def show_gradecards(request):
    db = SessionLocal()
    students = db.query(Student).order_by(Student.name).all()
    db.close()
    return templates.TemplateResponse("index.html", {
        "request": request,
        "students": students
    })

@app.post("/add-student")
def add_student(
    name: str = Form(...),
    marks: int = Form(...)
):
    grade = calculate_grade(marks)
    db = SessionLocal()
    new_student = Student(name=name, marks=marks, grade=grade)
    db.add(new_student)
    db.commit()
    db.close()
    return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)

@app.get("/test")
def test():
    return {"message": "FastAPI is working"}