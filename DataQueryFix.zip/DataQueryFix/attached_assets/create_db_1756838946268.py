from database import engine, Base
from models import Student

Base.metadata.create_all(bind=engine)
print("Database and tables created.")