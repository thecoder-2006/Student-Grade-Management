import { useQuery } from "@tanstack/react-query";
import { type Student } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award, GraduationCap, Target } from "lucide-react";

function getRankIcon(rank: number) {
  if (rank === 1) return <Trophy className="h-5 w-5 text-yellow-500" />;
  if (rank === 2) return <Medal className="h-5 w-5 text-gray-400" />;
  if (rank === 3) return <Award className="h-5 w-5 text-orange-500" />;
  return <div className="h-5 w-5 flex items-center justify-center text-sm font-bold text-muted-foreground">#{rank}</div>;
}

function getGradeBadgeColor(grade: string) {
  switch (grade) {
    case "A+": return "bg-green-100 text-green-800 border-green-200";
    case "A": return "bg-blue-100 text-blue-800 border-blue-200";
    case "B": return "bg-cyan-100 text-cyan-800 border-cyan-200";
    case "C": return "bg-yellow-100 text-yellow-800 border-yellow-200";
    case "D": return "bg-orange-100 text-orange-800 border-orange-200";
    case "F": return "bg-red-100 text-red-800 border-red-200";
    default: return "bg-gray-100 text-gray-800 border-gray-200";
  }
}

export default function Leaderboard() {
  const { data: students = [], isLoading, error } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-destructive mb-2">Error Loading Leaderboard</h2>
          <p className="text-muted-foreground">Please try refreshing the page</p>
        </div>
      </div>
    );
  }

  // Sort students by marks (highest first)
  const rankedStudents = [...students]
    .sort((a, b) => b.marks - a.marks)
    .map((student, index) => ({
      ...student,
      rank: index + 1
    }));

  const topPerformers = rankedStudents.slice(0, 3);
  const remainingStudents = rankedStudents.slice(3);

  const stats = {
    totalStudents: students.length,
    averageMarks: Math.round(students.reduce((sum, s) => sum + s.marks, 0) / students.length),
    topScore: rankedStudents[0]?.marks || 0,
    passRate: Math.round((students.filter(s => s.marks >= 50).length / students.length) * 100)
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-yellow-500 text-white p-2 rounded-lg">
                <Trophy className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Leaderboard</h1>
                <p className="text-sm text-muted-foreground">Top performing students</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary" data-testid="text-total-students">{stats.totalStudents}</div>
              <div className="text-sm text-muted-foreground">Total Students</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600" data-testid="text-top-score">{stats.topScore}</div>
              <div className="text-sm text-muted-foreground">Highest Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600" data-testid="text-average-marks">{stats.averageMarks}</div>
              <div className="text-sm text-muted-foreground">Average Marks</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600" data-testid="text-pass-rate">{stats.passRate}%</div>
              <div className="text-sm text-muted-foreground">Pass Rate</div>
            </CardContent>
          </Card>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12" data-testid="loading-leaderboard">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <span className="ml-3 text-muted-foreground">Loading leaderboard...</span>
          </div>
        ) : (
          <>
            {/* Top 3 Performers */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-6">🏆 Top Performers</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {topPerformers.map((student) => (
                  <Card key={student.id} className={`relative overflow-hidden ${student.rank === 1 ? 'ring-2 ring-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50' : student.rank === 2 ? 'ring-2 ring-gray-400 bg-gradient-to-br from-gray-50 to-blue-50' : 'ring-2 ring-orange-400 bg-gradient-to-br from-orange-50 to-red-50'}`} data-testid={`card-top-performer-${student.id}`}>
                    <CardContent className="p-6 text-center">
                      <div className="flex justify-center mb-4">
                        {getRankIcon(student.rank)}
                      </div>
                      <h3 className="text-lg font-semibold text-foreground mb-2" data-testid={`text-name-${student.id}`}>{student.name}</h3>
                      <div className="text-3xl font-bold text-primary mb-2" data-testid={`text-marks-${student.id}`}>{student.marks}</div>
                      <Badge className={getGradeBadgeColor(student.grade)} data-testid={`badge-grade-${student.id}`}>
                        Grade {student.grade}
                      </Badge>
                      <div className="text-xs text-muted-foreground mt-2">
                        Rank #{student.rank}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* All Rankings Table */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Complete Rankings</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full" data-testid="table-leaderboard">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Rank</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Student</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted-foreground uppercase tracking-wider">Marks</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted-foreground uppercase tracking-wider">Grade</th>
                        <th className="px-6 py-3 text-center text-xs font-medium text-muted-foreground uppercase tracking-wider">Performance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {rankedStudents.map((student, index) => (
                        <tr key={student.id} className={`hover:bg-muted/50 ${student.rank <= 3 ? 'bg-muted/30' : ''}`} data-testid={`row-student-${student.id}`}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              {getRankIcon(student.rank)}
                              <span className="ml-2 text-sm font-medium text-foreground">#{student.rank}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="bg-primary/10 text-primary p-2 rounded-full mr-3">
                                <GraduationCap className="h-4 w-4" />
                              </div>
                              <span className="text-sm font-medium text-foreground" data-testid={`text-name-row-${student.id}`}>{student.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <span className="text-lg font-semibold text-foreground" data-testid={`text-marks-row-${student.id}`}>{student.marks}/100</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <Badge className={getGradeBadgeColor(student.grade)} data-testid={`badge-grade-row-${student.id}`}>
                              {student.grade}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <div className="w-full bg-muted rounded-full h-2 max-w-[100px] mx-auto">
                              <div 
                                className={`h-2 rounded-full ${student.marks >= 90 ? 'bg-green-500' : student.marks >= 80 ? 'bg-blue-500' : student.marks >= 70 ? 'bg-cyan-500' : student.marks >= 60 ? 'bg-yellow-500' : student.marks >= 50 ? 'bg-orange-500' : 'bg-red-500'}`}
                                style={{ width: `${student.marks}%` }}
                                data-testid={`progress-row-${student.id}`}
                              />
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}