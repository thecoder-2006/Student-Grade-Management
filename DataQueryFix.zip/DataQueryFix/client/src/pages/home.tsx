import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Student } from "@shared/schema";
import StudentCard from "@/components/student-card";
import AddStudentForm from "@/components/add-student-form";
import SearchForm from "@/components/search-form";
import GradeStats from "@/components/grade-stats";
import { GraduationCap, Grid, Download } from "lucide-react";

export default function Home() {
  const [searchName, setSearchName] = useState("");
  const [searchGrade, setSearchGrade] = useState("");

  const { data: students = [], isLoading, error } = useQuery<Student[]>({
    queryKey: ["/api/students/search", searchName, searchGrade].filter(Boolean),
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchName) params.append('name', searchName);
      if (searchGrade && searchGrade !== 'ALL') params.append('grade', searchGrade);
      
      const url = params.toString() ? `/api/students/search?${params}` : '/api/students';
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to fetch students');
      }
      return response.json();
    }
  });

  const handleClearFilters = () => {
    setSearchName("");
    setSearchGrade("");
  };

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-destructive mb-2">Error Loading Students</h2>
          <p className="text-muted-foreground">Please try refreshing the page</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                <GraduationCap className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Student Grade Management</h1>
                <p className="text-sm text-muted-foreground">Track and manage student performance</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-foreground" data-testid="text-total-students">
                  {students.length} Students
                </p>
                <p className="text-xs text-muted-foreground">Total Enrolled</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <SearchForm
              searchName={searchName}
              searchGrade={searchGrade}
              onSearchNameChange={setSearchName}
              onSearchGradeChange={setSearchGrade}
              onClearFilters={handleClearFilters}
            />
            
            <AddStudentForm />
            
            <GradeStats students={students} />
          </div>
          
          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Student Grade Cards</h2>
                <p className="text-muted-foreground mt-1" data-testid="text-showing-count">
                  Showing {students.length} students
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  data-testid="button-toggle-view"
                  className="p-2 bg-secondary text-secondary-foreground hover:bg-accent rounded-md transition-colors"
                >
                  <Grid className="h-4 w-4" />
                </button>
                <button 
                  data-testid="button-export-data"
                  className="p-2 bg-secondary text-secondary-foreground hover:bg-accent rounded-md transition-colors"
                >
                  <Download className="h-4 w-4" />
                </button>
              </div>
            </div>
            
            {isLoading ? (
              <div className="flex justify-center items-center py-12" data-testid="loading-students">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                <span className="ml-3 text-muted-foreground">Loading students...</span>
              </div>
            ) : students.length === 0 ? (
              <div className="text-center py-12" data-testid="empty-state">
                <div className="text-muted-foreground mb-4">
                  <GraduationCap className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">No students found</h3>
                <p className="text-muted-foreground">
                  {searchName || searchGrade 
                    ? "Try adjusting your search criteria or add a new student."
                    : "Add your first student to get started."
                  }
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6" data-testid="student-grid">
                {students.map((student) => (
                  <StudentCard key={student.id} student={student} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
