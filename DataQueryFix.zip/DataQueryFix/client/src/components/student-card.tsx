import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { type Student } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStudentSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { User, Edit, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface StudentCardProps {
  student: Student;
}

function getGradeColor(grade: string) {
  switch (grade) {
    case "A+":
      return "bg-green-100 text-green-800";
    case "A":
      return "bg-blue-100 text-blue-800";
    case "B":
      return "bg-cyan-100 text-cyan-800";
    case "C":
      return "bg-yellow-100 text-yellow-800";
    case "D":
      return "bg-orange-100 text-orange-800";
    case "F":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
}

function getProgressColor(marks: number) {
  if (marks >= 90) return "bg-green-500";
  if (marks >= 80) return "bg-blue-500";
  if (marks >= 70) return "bg-cyan-500";
  if (marks >= 60) return "bg-yellow-500";
  if (marks >= 50) return "bg-orange-500";
  return "bg-red-500";
}

export default function StudentCard({ student }: StudentCardProps) {
  const [isEditOpen, setIsEditOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(insertStudentSchema),
    defaultValues: {
      name: student.name,
      marks: student.marks,
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: { name: string; marks: number }) => {
      await apiRequest("PUT", `/api/students/${student.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      setIsEditOpen(false);
      toast({
        title: "Student updated",
        description: "Student information has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update student. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/students/${student.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({
        title: "Student deleted",
        description: "Student has been removed from the system.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete student. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: { name: string; marks: number }) => {
    updateMutation.mutate(data);
  };

  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete ${student.name}?`)) {
      deleteMutation.mutate();
    }
  };

  return (
    <>
      <Card className="hover:shadow-md transition-shadow" data-testid={`card-student-${student.id}`}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="bg-primary/10 text-primary p-2 rounded-full">
                <User className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground" data-testid={`text-name-${student.id}`}>
                  {student.name}
                </h3>
                <p className="text-sm text-muted-foreground">Student ID: #{student.id}</p>
              </div>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(student.grade)}`} 
                  data-testid={`text-grade-${student.id}`}>
              {student.grade}
            </span>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Marks Obtained</span>
              <span className="font-semibold text-foreground" data-testid={`text-marks-${student.id}`}>
                {student.marks}/100
              </span>
            </div>
            
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${getProgressColor(student.marks)}`}
                style={{ width: `${student.marks}%` }}
                data-testid={`progress-${student.id}`}
              />
            </div>
            
            <div className="flex items-center space-x-2 pt-2">
              <Button 
                variant="secondary"
                size="sm"
                className="flex-1"
                onClick={() => setIsEditOpen(true)}
                data-testid={`button-edit-${student.id}`}
              >
                <Edit className="h-3 w-3 mr-1" />
                Edit
              </Button>
              <Button 
                variant="destructive"
                size="sm"
                onClick={handleDelete}
                disabled={deleteMutation.isPending}
                data-testid={`button-delete-${student.id}`}
                className="bg-destructive/10 text-destructive hover:bg-destructive/20"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Student</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Student Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter full name..." 
                        data-testid={`input-edit-name-${student.id}`}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="marks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Marks (0-100)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={0} 
                        max={100}
                        placeholder="Enter marks..."
                        data-testid={`input-edit-marks-${student.id}`}
                        {...field} 
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-3 pt-4">
                <Button 
                  type="button"
                  variant="secondary"
                  className="flex-1"
                  onClick={() => setIsEditOpen(false)}
                  data-testid={`button-cancel-edit-${student.id}`}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  className="flex-1"
                  disabled={updateMutation.isPending}
                  data-testid={`button-save-edit-${student.id}`}
                >
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
}
