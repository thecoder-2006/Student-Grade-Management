import { useMemo } from "react";
import { type Student } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

interface GradeStatsProps {
  students: Student[];
}

export default function GradeStats({ students }: GradeStatsProps) {
  const stats = useMemo(() => {
    const gradeCount = students.reduce((acc, student) => {
      acc[student.grade] = (acc[student.grade] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      excellent: (gradeCount["A+"] || 0) + (gradeCount["A"] || 0),
      good: (gradeCount["B"] || 0) + (gradeCount["C"] || 0),
      average: gradeCount["D"] || 0,
      fail: gradeCount["F"] || 0,
    };
  }, [students]);

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Grade Distribution</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm text-foreground">A+ & A</span>
            </div>
            <span className="text-sm font-medium text-foreground" data-testid="text-excellent-count">
              {stats.excellent}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm text-foreground">B & C</span>
            </div>
            <span className="text-sm font-medium text-foreground" data-testid="text-good-count">
              {stats.good}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
              <span className="text-sm text-foreground">D</span>
            </div>
            <span className="text-sm font-medium text-foreground" data-testid="text-average-count">
              {stats.average}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-sm text-foreground">F</span>
            </div>
            <span className="text-sm font-medium text-foreground" data-testid="text-fail-count">
              {stats.fail}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
