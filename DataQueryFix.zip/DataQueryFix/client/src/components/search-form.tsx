import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, User } from "lucide-react";

interface SearchFormProps {
  searchName: string;
  searchGrade: string;
  onSearchNameChange: (value: string) => void;
  onSearchGradeChange: (value: string) => void;
  onClearFilters: () => void;
}

export default function SearchForm({ 
  searchName, 
  searchGrade, 
  onSearchNameChange, 
  onSearchGradeChange, 
  onClearFilters 
}: SearchFormProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Search className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Search Students</h2>
        </div>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="searchName" className="text-sm font-medium text-foreground mb-2">
              Search by Name
            </Label>
            <div className="relative">
              <Input 
                id="searchName"
                type="text"
                placeholder="Enter student name..."
                value={searchName}
                onChange={(e) => onSearchNameChange(e.target.value)}
                className="pl-10"
                data-testid="input-search-name"
              />
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
          
          <div>
            <Label htmlFor="searchGrade" className="text-sm font-medium text-foreground mb-2">
              Filter by Grade
            </Label>
            <Select value={searchGrade} onValueChange={onSearchGradeChange}>
              <SelectTrigger data-testid="select-grade-filter">
                <SelectValue placeholder="All Grades" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Grades</SelectItem>
                <SelectItem value="A+">A+ (90-100)</SelectItem>
                <SelectItem value="A">A (80-89)</SelectItem>
                <SelectItem value="B">B (70-79)</SelectItem>
                <SelectItem value="C">C (60-69)</SelectItem>
                <SelectItem value="D">D (50-59)</SelectItem>
                <SelectItem value="F">F (Below 50)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            variant="secondary"
            className="w-full"
            onClick={onClearFilters}
            data-testid="button-clear-filters"
          >
            Clear Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
