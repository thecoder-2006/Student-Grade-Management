import { type Student, type InsertStudent, students } from "@shared/schema";
import { db, initDatabase } from "./db";
import { eq, and, like, asc } from "drizzle-orm";

export interface IStorage {
  // Student methods
  getStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;
  searchStudents(name?: string, grade?: string): Promise<Student[]>;

  // User methods (keeping for compatibility)
  getUser(id: string): Promise<any>;
  getUserByUsername(username: string): Promise<any>;
  createUser(user: any): Promise<any>;
}

export class SqliteStorage implements IStorage {
  constructor() {
    initDatabase();
  }

  async getStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(asc(students.name));
  }

  async getStudent(id: number): Promise<Student | undefined> {
    const result = await db.select().from(students).where(eq(students.id, id));
    return result[0];
  }

  async createStudent(studentData: InsertStudent): Promise<Student> {
    const grade = this.calculateGrade(studentData.marks);
    const insertData = { ...studentData, grade };
    
    const result = await db.insert(students).values(insertData).returning();
    return result[0];
  }

  async updateStudent(id: number, studentData: Partial<InsertStudent>): Promise<Student | undefined> {
    const existingStudent = await this.getStudent(id);
    if (!existingStudent) {
      return undefined;
    }

    const updatedData: any = { ...studentData };
    if (studentData.marks !== undefined) {
      updatedData.grade = this.calculateGrade(studentData.marks);
    }

    const result = await db.update(students)
      .set(updatedData)
      .where(eq(students.id, id))
      .returning();
    
    return result[0];
  }

  async deleteStudent(id: number): Promise<boolean> {
    const result = await db.delete(students).where(eq(students.id, id));
    return result.changes > 0;
  }

  async searchStudents(name?: string, grade?: string): Promise<Student[]> {
    const conditions = [];
    if (name) {
      conditions.push(like(students.name, `%${name}%`));
    }
    if (grade) {
      conditions.push(eq(students.grade, grade));
    }

    if (conditions.length > 0) {
      return await db.select().from(students)
        .where(and(...conditions))
        .orderBy(asc(students.name));
    }

    return await db.select().from(students).orderBy(asc(students.name));
  }

  private calculateGrade(marks: number): string {
    if (marks >= 90) return "A+";
    if (marks >= 80) return "A";
    if (marks >= 70) return "B";
    if (marks >= 60) return "C";
    if (marks >= 50) return "D";
    return "F";
  }

  // User methods for compatibility
  async getUser(id: string): Promise<any> {
    return undefined;
  }

  async getUserByUsername(username: string): Promise<any> {
    return undefined;
  }

  async createUser(user: any): Promise<any> {
    return user;
  }
}

export const storage = new SqliteStorage();
