import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import { students } from "@shared/schema";
import path from "path";

const dbPath = path.join(process.cwd(), "students.db");
const sqlite = new Database(dbPath);
export const db = drizzle(sqlite);

// Initialize the database
export function initDatabase() {
  // Create students table if it doesn't exist
  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      marks INTEGER NOT NULL,
      grade TEXT NOT NULL
    )
  `);

  // Check if we have any students, if not, populate with sample data
  const count = sqlite.prepare("SELECT COUNT(*) as count FROM students").get() as { count: number };
  
  if (count.count === 0) {
    const sampleStudents = [
      { name: 'Aditi Sharma', marks: 92, grade: 'A+' },
      { name: 'Rohan Gupta', marks: 85, grade: 'A' },
      { name: 'Meera Patel', marks: 76, grade: 'B' },
      { name: 'Kabir Singh', marks: 67, grade: 'C' },
      { name: 'Tina Kumar', marks: 55, grade: 'D' },
      { name: 'Arjun Mehta', marks: 45, grade: 'F' },
      { name: 'Sneha Reddy', marks: 88, grade: 'A' },
      { name: 'Rahul Jain', marks: 73, grade: 'B' },
      { name: 'Priya Agarwal', marks: 91, grade: 'A+' },
      { name: 'Vikram Shah', marks: 62, grade: 'C' }
    ];

    const insertStmt = sqlite.prepare("INSERT INTO students (name, marks, grade) VALUES (?, ?, ?)");
    for (const student of sampleStudents) {
      insertStmt.run(student.name, student.marks, student.grade);
    }
  }
}
